package com.example.pima.collapsingtoolbar;

import android.content.Intent;
import android.nfc.cardemulation.CardEmulation;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

import com.example.pima.navigationdrawer.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private CardView planCard, wykladowcyCard, kalendarzCard, notatkiCard, zastepstwaCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        planCard = (CardView) findViewById(R.id.plan_card);
        wykladowcyCard = (CardView) findViewById(R.id.wykladowcy_card);
        kalendarzCard = (CardView) findViewById(R.id.kalendarz_card);
        notatkiCard = (CardView) findViewById(R.id.notatki_card);
        zastepstwaCard = (CardView) findViewById(R.id.zastepstwa_card);

        planCard.setOnClickListener(this);
        wykladowcyCard.setOnClickListener(this);
        kalendarzCard.setOnClickListener(this);
        notatkiCard.setOnClickListener(this);
        zastepstwaCard.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
    Intent i ;

    switch (v.getId()) {
        case R.id.plan_card:
            i = new Intent(this, plan.class);
            startActivity(i);
            break;
        case R.id.wykladowcy_card:
            i = new Intent(this, wykladowcy.class);
            startActivity(i);
            break;
        case R.id.kalendarz_card:
            i = new Intent(this, kalendarz.class);
            startActivity(i);
            break;
        case R.id.notatki_card:
            i = new Intent(this, notatki.class);
            startActivity(i);
            break;
        case R.id.zastepstwa_card:
            i = new Intent(this, zastepstwa.class);
            startActivity(i);
            break;
        default:
            break;
    }

    }
}